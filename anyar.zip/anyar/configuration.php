<?php 
	$configuracion['servidor']='localhost';
	$configuracion['usuario']='root';
	$configuracion['contrasena']='';
	$configuracion['base_datos']='compsys';
 ?>