<?php 

	$conexion=mysqli_connect('localhost','root','','compsys') or die ("Error de conexion a la BD" .mysqli_error($conexion));
	
?>