<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>COMPSYS</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/font-awesome.css">
	<link rel="stylesheet" href="css/animate.css">
	<link href="css/style.css" rel="stylesheet" />
	<link rel="stylesheet" type="text/css" href="css/styles.css">	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
	<header>
		<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
			<div class="navigation">
				<div class="container">					
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse.collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<div class="">
							<img src="img/logo.png" width="90" height="70">
						</div>
					</div>
					
					<div class="navbar-collapse collapse">							
						<div class="menu">
							<ul class="nav nav-tabs" role="tablist">
								<li role="presentation"><a href="#home">Inicio</a></li>
								<li role="presentation"><a href="#about">Acerca de nosotros</a></li>
								<li role="presentation"><a href="#services">Servicios</a></li>																
								<li role="presentation"><a href="#contact">Contactos</a></li>
								<li role="presentation"><a href="../glpi/index.php">GLPI</a></li>
								<li role="presentation"><a href="../hepldesk/admin/index.php">HelpDesk</a></li>

								<li role="presentation"><a href="exit.php">Salir</a></li>	
							</ul>
						</div>
					</div>						
				</div>
			</div>	
		</nav>			
	</header>
	
	 <div id="home">
		<div class="slider">
			<div class="">
				<div id="about-slider">
					<div id="carousel-slider" class="carousel slide" data-ride="carousel">
						<!-- Indicators -->
						<ol class="carousel-indicators visible-xs">
							<li data-target="#carousel-slider" data-slide-to="0" class="active"></li>
							<li data-target="#carousel-slider" data-slide-to="1"></li>
							<li data-target="#carousel-slider" data-slide-to="2"></li>
						</ol>

						<div class="carousel-inner">
							<div class="item active">
								<img src="img/association.png" class="img-responsive" alt=""> 
						   </div>
						   <div class="item">
								<img src="img/association.png" class="img-responsive" alt=""> 
						   </div> 
						   <div class="item">
								<img src="img/association.png" class="img-responsive" alt=""> 
						   </div> 
						</div>
						
						<a class="left carousel-control hidden-xs" href="#carousel-slider" data-slide="prev">
							<i class="fa fa-angle-left"></i> 
						</a>
						
						<a class=" right carousel-control hidden-xs"href="#carousel-slider" data-slide="next">
							<i class="fa fa-angle-right"></i> 
						</a>
					</div> <!--/#carousel-slider-->
				</div><!--/#about-slider-->
			</div>
		</div>
	</div>
	
	<section id="about">
		<div class="container">
			<div class="center">
				<div class="col-md-12">
					<h2>Acerca de nosotros</h2>
					<hr>					
					<p class="about" style="text-align: justify; font-size: 16px; margin-bottom: 50px;" >Compsys fue fundada en 1992 por Robert Williams. Robert tenía una visión de una compañía de TI de servicio completo que priorizara a sus clientes. Compsys se originó desde un comienzo humilde, Robert dirigía la empresa desde los confines de su hogar. A medida que Compsys creció, pronto se quedó sin espacio en casa y abrió una pequeña oficina en North Little Rock, Arkansas. Compsys ha estado creciendo desde entonces.

					En Compsys operamos bajo la filosofía de que nuestros clientes son más que simples clientes, son nuestros amigos. Trabajamos duro para desarrollar y cultivar relaciones con nuestros clientes y siempre nos esforzamos por lograr la satisfacción del cliente. Compsys es la mejor opción para subcontratar su TI porque hacemos un esfuerzo adicional para nuestros clientes sin dejar de ser muy competitivos con nuestros precios. Tratamos a nuestros clientes como quisiéramos ser tratados. Tenemos técnicos experimentados que trabajan para usted con una sonrisa. Tenemos el mismo tiempo de respuesta, independientemente de cuán grandes o pequeñas sean sus necesidades de TI. Tenemos clientes en un amplio espectro de industrias, tales como prácticas legales, instalaciones médicas, gobiernos estatales y locales, empresas de publicidad, empresas de contabilidad, compañías hipotecarias, bancos y muchos más. Trabajaremos con usted y adaptaremos una solución que mejor se adapte a sus necesidades. No todas las empresas necesitan la misma solución y lo entendemos. Actuaremos como su CIO (director de información) si lo desea. Estaremos encantados de celebrar consultas para determinar las mejores prácticas comerciales desde el punto de vista de TI.</p>
				</div>
			</div>
		</div>
    </section>
	
	<div id="services">
		<div class="container">
			<div class="center">
				<div class="col-md-6 col-md-offset-3">
					<h2>servicios</h2>
					<hr>
				</div>
			</div>
		</div>
		<div class="container">
			<div class="text-center">
				<div class="col-md-3 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
					<img src="img/services/services1.png">
					<h3>Servicios en la nube</h3>
					<p>Compsys ofrece una amplia gama de servicios en la nube que pueden ayudar a su empresa a ser más móvil y ahorrar costos.</p>
				</div>
				<div class="col-md-3 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
					<img src="img/services/services5.png">
					<h3>Administración de redes</h3>
					<p>¡Ofrecemos soluciones personalizadas para administrar sus estaciones de trabajo, servidores, equipos de red y todas las demás necesidades de TI!</p>
				</div>
				<div class="col-md-3 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="900ms">
					<img src="img/services/services6.png">
					<h3>Servicios en el sitio</h3>
					<p>La mayoría de los problemas informáticos actuales se pueden resolver de forma remota mediante el uso de un software de soporte remoto, pero a veces aún es necesario tener un técnico en el sitio. Ofrecemos soporte informático in situ para cualquier empresa dentro de Arkansas.
					También ofrecemos una gama de otros servicios en el lugar para satisfacer sus necesidades.</p>
				</div>
				<div class="col-md-3 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="1200ms">
					<img src="img/services/services1.png">
					<h3>Servicios de respaldo y recuperación de desastres</h3>
					<p>Su empresa ya no tendrá que preocuparse por la pérdida de datos o el dolor de cabeza y la pérdida de productividad.</p>
				</div>
			</div>	
		</div>		
	</div>
	
	<div id="feature">
		<div class="container">
			<div class="text-center">
				<div class="col-md-4">
					<div class="hi-icon-wrap hi-icon-effect wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms" >
						<i class="fa fa-windows"></i>	
						<h3>El último receptor Citrix para Windows</h3>
						<p>Esto lo llevará a la página de descarga de Citrix para obtener el último Citrix Receiver</p>
					</div>
				</div>				
				<div class="col-md-4">
					<div class="hi-icon-wrap hi-icon-effect wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms" >
						<i class="fa fa-windows"></i>	
						<h3>Receptor para Windows XP</h3>
						<p>[wpdm_package id = '35675']</p>
					</div>
				</div>
				<div class="col-md-4">
					<div class="hi-icon-wrap hi-icon-effect wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="900ms" >
						<i class="fa fa-apple"></i>	
						<h3>Receptor para Mac 10.6</h3>
						<p>[wpdm_package id = '35671']</p>
					</div>
				</div>
			</div>
		</div>
	</div>
			
	<div id="contact">
		<div class="container">
			<div class="col-lg-8">
				<div class="map">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2501.3373568083903!2d-92.38051338865557!3d34.825747638563726!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87d2a240af51e289%3A0x3152523e27af979c!2sCompsys%2C+Inc!5e0!3m2!1ses-419!2sco!4v1527629816752"></iframe>
				</div>
			</div>
			<section id="contact-page">
				<div class="container">
					<div class="center">        
						<h3>Deja su mensaje</h3>
					</div> 
					<div class="col-lg-4">
						<div class="row contact-wrap"> 
							<div class="status alert alert-success" style="display: none"></div>
							<form id="main-contact-form" class="contact-form" name="contact-form" method="post" action="sendemail.php">							
								<div class="form-group">
									<label>Nombre *</label>
									<input type="text" name="name" class="form-control" required="required">
								</div>
								<div class="form-group">
									<label>Email *</label>
									<input type="email" name="email" class="form-control" required="required">
								</div>															                    													
								<div class="form-group">
									<label>Tema *</label>
									<input type="text" name="subject" class="form-control" required="required">
								</div>
								<div class="form-group">
									<label>Mensaje *</label>
									<textarea name="message" id="message" required="required" class="form-control" rows="8"></textarea>
								</div>                        
								<div class="form-group pull-right">
									<button type="submit" name="submit" class="button btn-primary btn-lg" required="required">Enviar mensaje</button>
								</div>						
							</form> 
						</div><!--/.row-->
					</div>
				</div><!--/.container-->
			</section><!--/#contact-page-->
		</div>
	</div>

	<footer class="footer">
		<div class="container">
			<div class="col-md-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
				<h4>Acerca de</h4>						
				<div class="contact-info">
					<ul>
						<li><i class="fa fa-home fa"></i>Direcci&oacute;n: 10603 Maumelle Blvd, North Little Rock, AR </li>
						<li><i class="fa fa-phone fa"></i> N&uacute;meros de tel&acute;fono: (877) 644-6818, (501) 758-6818</li>
						<li><i class="fa fa-envelope fa"></i> Email: sales@compsys.com</li>
					</ul>
				</div>
			</div>
			
			<div class="col-md-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">				
				<div class="text-center">
					<h4>Galeria de fotos</h4>
					<ul class="sidebar-gallery">
						<li><a href="#"><img src="img/community.jpg" alt="" width="" /></a></li>
						<li><a href="#"><img src="img/networking.jpg" alt="" /></a></li>
						<li><a href="#"><img src="img/IP.jpg" alt="" /></a></li>
						<li><a href="#"><img src="img/cloud.png" alt="" /></a></li>					
					</ul>
				</div>
			</div>
		</div>	
	</footer>
	
	<div class="two-footer">
		<div class="container">
			<div class="social-icon">
				<div class="col-md-4">
					<ul class="social-network">
						<li><a href="#" class="fb tool-tip" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" class="twitter tool-tip" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#" class="gplus tool-tip" title="Google Plus"><i class="fa fa-google-plus"></i></a></li>
						<li><a href="#" class="linkedin tool-tip" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#" class="ytube tool-tip" title="You Tube"><i class="fa fa-youtube-play"></i></a></li>
					</ul>	
				</div>
			</div>
			
			<div class="col-md-4 col-md-offset-4">
				<div class="copyright">
					Copyright © 2016 Compsys - Computer Systems and Services
                    <!-- 
                        All links in the footer should remain intact. 
                        Licenseing information is available at: http://bootstraptaste.com/license/
                        You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=Anyar
                    -->
				</div>
			</div>						
		</div>				
	</div>
	
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery.js"></script>	
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>	
	<script src="js/jquery.isotope.min.js"></script> 
	<script src="js/functions.js"></script>
  </body>
</html>