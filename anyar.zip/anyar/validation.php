<?php  

		$user=$_REQUEST["user"];
		$password=$_REQUEST["password"];
		require_once('connection.php');

		

		$mysql=mysqli_query($conexion, "SELECT * FROM registry WHERE user = '$user' AND password = '$password'");
		$login = mysqli_fetch_array($mysql);

		if ($user == $login["user"] && $password == $login["password"]){	
	 		header("location:page.php");
	 	}


	 	// $user_sql = mysqli_query("SELECT * FROM registry WHERE user = '$user'");
	 	// if ($function = mysqli_fetch_array($user_sql)) {
	 	// 	if ($password == $function['password']) {
	 	// 		header("location:page.php");
	 	// 	}else{
	 	// 		echo '<script>alert("Contraseña incorrecta");</script>';
	 	// 		echo '<script>location.href=index.php</script>';
	 	// 	}
	 	// }else{
	 	// 	echo '<script>alert("Este usuario no existe");</script>';
	 	// 	echo '<script>location.href=index.php</script>';
	 	// }
 
?>
