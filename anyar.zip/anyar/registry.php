<?php
	session_start();
?>
<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>COMPSYS</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/font-awesome.css">
	<link rel="stylesheet" href="css/animate.css">
	<link href="css/style.css" rel="stylesheet" />	
	<link rel="stylesheet" type="text/css" href="css/styles.css">
  </head>
  <body>
	<header>
		<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
			<div class="navigation">
				<div class="container">					
					<div class="navbar-header">
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse.collapse">
							<span class="sr-only">Toggle navigation</span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
							<span class="icon-bar"></span>
						</button>
						<div class="">
							<img src="img/logo.png" width="90" height="70">
						</div>
					</div>
					<div class="navbar-collapse collapse">							
						<div class="menu">
							<ul class="nav nav-tabs" role="tablist">
								<li role="presentation"><a href="index.php" class="action">Ingresar</a></li>					
							</ul>
						</div>
					</div>						
				</div>
			</div>	
		</nav>			
	</header><br><br><br><br>
	<div class="container">
		<form action="create_user.php" method="POST" class="jumbotron form">
			<h2 class="tex">Iniciar Sesi&oacute;n</h2>
			<div>
				<label for="user" class="text">Usuario</label>
				<input type="text" class="form-control col-lg-4" name="user" placeholder="Usuario" required="">
			</div>
			<div>
				<label for="password" class="text">Clave</label>
				<input type="password" class="form-control col-lg-4" name="password" placeholder="Clave" required="">
			</div>
			<div>
				<label for="repeat_password" class="text">Confirmar Clave</label>
				<input type="password" class="form-control col-lg-4" name="repeat_password" placeholder="Confirmar Clave" required="">
			</div>
			<div class="pull-right">
				<input type="submit" class="button btn-success" name="" value="Ingresar">
			</div>
			<div>
				<button style="margin-left: 250px;" type="reset" class="button btn-danger">Cancelar</button>
			</div>
		</form>
	</div>	
	
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<script src="js/jquery.js"></script>	
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
	<script src="js/wow.min.js"></script>
	<script src="js/jquery.easing.min.js"></script>	
	<script src="js/jquery.isotope.min.js"></script> 
	<script src="js/functions.js"></script>
  </body>
</html>