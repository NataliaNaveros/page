<?php
	
	
	if (isset($_REQUEST['user']) && isset($_REQUEST['password'])&&isset($_REQUEST['repeat_password'])){
		$user=$_REQUEST["user"];
		$password=$_REQUEST["password"];
		$repeat_password=$_REQUEST["repeat_password"];

		if ($password == $repeat_password) {
			require_once("connection.php");
			$insert = mysqli_query($conexion,"INSERT INTO registry (user, password) 
				VALUES ('$user','$password')");
			$query = mysqli_affected_rows($conexion);
			if ($query == 1) {
				echo '<script language = "javascript">alert("Usuario registrado con exito");</script>';
				header("location: index.php");
			}else{
				echo '<script language = "javascript">alert("El usuario no fue registrado vuelva a intentarlo nuevamente");</script>';

			}
		
		}else{
				echo '<script language = "javascript">alert("Contraseñas no coinciden");</script>';
			
		}
	}

?>